package com.example.kimochinikki.bean

class DiaryBean(val day: String, val title: String) {
}
