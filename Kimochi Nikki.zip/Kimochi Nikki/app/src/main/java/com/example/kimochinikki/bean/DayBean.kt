package com.example.kimochinikki.bean

class DayBean {
    var day: Int = 0
    var month: Int = 0
    var year: Int = 0
    var currentMonth: Boolean = false
    var currentDay: Boolean = false
}
